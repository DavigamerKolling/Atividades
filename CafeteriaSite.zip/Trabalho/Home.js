// Verifica se há usuário logado na sessão
const usuario = sessionStorage.getItem("usuarioLogado");
const info = document.getElementById("info-usuario");

if (!usuario) {
  alert("Você precisa fazer login.");
  window.location.href = "Login.html";
} else {
  info.textContent = `Usuário logado: ${usuario}`;
}

// Função de logout
function logout() {
  sessionStorage.clear();
  window.location.href = "Login.html";
}

// Expor a função para o botão no HTML
window.logout = logout;
