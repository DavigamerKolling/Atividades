document.getElementById('login-form').addEventListener('submit', function (event) {
  event.preventDefault();

  const inputs = document.querySelectorAll('#login-form input');
  const email = inputs[0].value.trim();
  const senha = inputs[1].value;

  if (!email || !senha) {
    alert('Por favor, preencha todos os campos.');
    return;
  }

  // Verifica credenciais fixas
  if (email === "cliente@cafeteria.com" && senha === "123456") {
    alert("Login bem-sucedido! ☕ Bem-vindo à Cafeteria.");
    // window.location.href = "home.html"; // Redirecionar, se desejar
  } else {
    alert("Email ou senha incorretos.");
  }
});
