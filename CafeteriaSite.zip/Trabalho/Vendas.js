const vendas = [
    { cliente: "Ana", data: "2025-06-01", valor: 28.50, pagamento: "cartao" },
    { cliente: "Bruno", data: "2025-06-02", valor: 15.00, pagamento: "pix" },
    { cliente: "Carla", data: "2025-06-02", valor: 9.90, pagamento: "dinheiro" }
  ];
  
  const tabela = document.getElementById("corpo-tabela");
  const busca = document.getElementById("busca");
  const filtro = document.getElementById("filtro");
  
  function renderizarVendas(lista) {
    tabela.innerHTML = "";
  
    lista.forEach(venda => {
      const tr = document.createElement("tr");
  
      tr.innerHTML = `
        <td>${venda.cliente}</td>
        <td>${venda.data}</td>
        <td>R$ ${venda.valor.toFixed(2)}</td>
        <td>${venda.pagamento}</td>
        <td><button class="ver-detalhes">Detalhes</button></td>
      `;
  
      tabela.appendChild(tr);
    });
  }
  
  function filtrarVendas() {
    const termo = busca.value.toLowerCase();
    const tipo = filtro.value;
  
    const resultado = vendas.filter(venda => {
      const correspondeBusca = venda.cliente.toLowerCase().includes(termo);
      const correspondeFiltro = tipo === "" || venda.pagamento === tipo;
      return correspondeBusca && correspondeFiltro;
    });
  
    renderizarVendas(resultado);
  }
  
  busca.addEventListener("input", filtrarVendas);
  filtro.addEventListener("change", filtrarVendas);
  
  // Inicializar
  renderizarVendas(vendas);
  