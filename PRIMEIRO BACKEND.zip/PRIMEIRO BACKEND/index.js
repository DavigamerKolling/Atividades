const express = require('express');
const app = express();
const path = require("path");


app.get("/", async (req,res)=> {
    res.sendFile(path.join(__dirname, 'src', 'index.html'));
});

app.listen(8080, () => {
console.log("Servidor iniciado na porta 8080: http://localhost:8080");
});