const mazeMap = [
  [4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4],
  [4,1,1,1,1,1,1,1,4,4,4,4,1,1,1,1,1,1,1,4],
  [4,1,4,4,1,4,4,1,4,4,4,4,1,4,4,1,4,4,1,4],
  [4,2,4,4,1,4,4,1,1,1,1,1,1,4,4,1,4,4,2,4],
  [4,1,4,4,1,4,4,1,4,4,4,4,1,4,4,1,4,4,1,4],
  [4,1,1,1,1,1,1,1,0,0,0,0,1,1,1,1,1,1,1,4],
  [4,4,4,1,4,4,1,4,4,0,0,4,4,1,4,4,1,4,4,4],
  [0,1,1,1,4,4,1,4,3,3,3,3,4,1,4,4,1,1,1,0],
  [4,4,4,1,4,4,1,4,4,4,4,4,4,1,4,4,1,4,4,4],
  [4,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,4],
  [4,1,4,1,4,1,4,4,4,4,4,4,4,4,1,4,1,4,1,4],
  [4,2,1,1,4,1,1,1,1,4,4,1,1,1,1,4,1,1,2,4],
  [4,1,4,4,4,1,4,4,1,4,4,1,4,4,1,4,4,4,1,4],
  [4,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,4],
  [4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4]
];

const container = document.getElementById("game-container");

mazeMap.forEach((row, y) => {
  row.forEach((cell, x) => {
    const tile = document.createElement("div");
    tile.classList.add("tile");

    switch (cell) {
      case 0:
        tile.classList.add("empty");
        break;
      case 1:
        tile.classList.add("pellet");
        break;
      case 2:
        tile.classList.add("power-pellet");
        break;
      case 3:
        tile.classList.add("ghost-zone");
        break;
      case 4:
        tile.classList.add("wall");
        break;
    }

    // Define a posição de cada tile no grid
    tile.style.left = x * 31 + "px";
    tile.style.top = y * 31 + "px";
    container.appendChild(tile);
  });
});

// Pac-Man config
const pacman = document.getElementById("pacman");
let pacX = 1;
let pacY = 1;
let direction = 'right';
let currentSpriteIndex = 0;
let isDead = false;

// Sprites fornecidos
let pacmanSprites = {
  up: ['./Sprite/PacMan/Eating/Up/UpEatFrame1.png', './Sprite/PacMan/Eating/Up/UpEatFrame2.png', './Sprite/PacMan/Eating/Up/UpEatFrame3.png'],
  down: ['./Sprite/PacMan/Eating/Down/DownEatFrame1.png', './Sprite/PacMan/Eating/Down/DownEatFrame2.png', './Sprite/PacMan/Eating/Down/DownEatFrame3.png'],
  left: ['./Sprite/PacMan/Eating/Left/LeftEatFrame1.png', './Sprite/PacMan/Eating/Left/LeftEatFrame2.png', './Sprite/PacMan/Eating/Left/LeftEatFrame3.png'],
  right: ['./Sprite/PacMan/Eating/Right/RightEatFrame1.png', './Sprite/PacMan/Eating/Right/RightEatFrame2.png', './Sprite/PacMan/Eating/Right/RightEatFrame3.png'],
  dying: [
    './Sprite/PacMan/Dying/DieFrame1.png', './Sprite/PacMan/Dying/DieFrame2.png', './Sprite/PacMan/Dying/DieFrame3.png',
    './Sprite/PacMan/Dying/DieFrame4.png', './Sprite/PacMan/Dying/DieFrame5.png', './Sprite/PacMan/Dying/DieFrame6.png',
    './Sprite/PacMan/Dying/DieFrame7.png', './Sprite/PacMan/Dying/DieFrame8.png', './Sprite/PacMan/Dying/DieFrame9.png',
    './Sprite/PacMan/Dying/DieFrame10.png', './Sprite/PacMan/Dying/DieFrame11.png'
  ]
};

// Função para criar fantasmas
function createGhost(name, x, y) {
  const ghost = document.createElement("div");
  ghost.id = name;
  ghost.classList.add("ghost");
  document.body.appendChild(ghost);
  ghost.style.left = x * 31 + "px";
  ghost.style.top = y * 31 + "px";
  return ghost;
}

// Definindo a posição inicial dos fantasmas no meio do labirinto
const ghosts = [
  { name: "blinky", element: createGhost("blinky", 8, 4), x: 8, y: 4 },
  { name: "pinky", element: createGhost("pinky", 8, 5), x: 8, y: 5 },
  { name: "inky", element: createGhost("inky", 9, 4), x: 9, y: 4 },
  { name: "clyde", element: createGhost("clyde", 9, 5), x: 9, y: 5 }
];

// Função para atualizar a posição dos fantasmas dentro do labirinto
function updateGhostsPosition() {
  ghosts.forEach((ghost) => {
    ghost.element.style.left = ghost.x * 31 + "px";
    ghost.element.style.top = ghost.y * 31 + "px";
  });
}

// Função para mover os fantasmas
function moveGhosts() {
  ghosts.forEach((ghost) => {
    const directions = ["up", "down", "left", "right"];
    const randomDirection = directions[Math.floor(Math.random() * directions.length)];
    let nextX = ghost.x;
    let nextY = ghost.y;

    switch (randomDirection) {
      case "up": nextY--; break;
      case "down": nextY++; break;
      case "left": nextX--; break;
      case "right": nextX++; break;
    }

    // Verifica se a nova posição é válida (não colidindo com paredes)
    if (
      nextX >= 0 &&
      nextX < mazeMap[0].length &&
      nextY >= 0 &&
      nextY < mazeMap.length &&
      mazeMap[nextY][nextX] !== 4 // Não pode passar por paredes
    ) {
      ghost.x = nextX;
      ghost.y = nextY;
    }
  });

  updateGhostsPosition();
}

// Movimentação do Pac-Man
function updatePacmanPosition() {
  pacman.style.left = pacX * 31 + "px";
  pacman.style.top = pacY * 31 + "px";
}

function updatePacmanSprite() {
  pacman.style.backgroundImage = `url(${pacmanSprites[direction][currentSpriteIndex]})`;
  currentSpriteIndex = (currentSpriteIndex + 1) % pacmanSprites[direction].length;
}

function movePacman(dir) {
  if (isDead) return;

  let nextX = pacX;
  let nextY = pacY;

  switch (dir) {
    case "ArrowUp": nextY--; direction = 'up'; break;
    case "ArrowDown": nextY++; direction = 'down'; break;
    case "ArrowLeft": nextX--; direction = 'left'; break;
    case "ArrowRight": nextX++; direction = 'right'; break;
  }

  if (
    nextY >= 0 &&
    nextY < mazeMap.length &&
    nextX >= 0 &&
    nextX < mazeMap[0].length &&
    mazeMap[nextY][nextX] !== 4 // Não pode passar por paredes
  ) {
    pacX = nextX;
    pacY = nextY;
    updatePacmanPosition();
    updatePacmanSprite();
  }
}

// Função para verificar colisão
function checkCollision() {
  if (isDead) return;

  ghosts.forEach((ghost) => {
    if (pacX === ghost.x && pacY === ghost.y) {
      isDead = true;
      animateDeath();
    }
  });
}

// Função para animar a morte
function animateDeath() {
  let deathInterval = setInterval(() => {
    pacman.style.backgroundImage = `url(${pacmanSprites.dying[currentSpriteIndex]})`;
    currentSpriteIndex++;
    if (currentSpriteIndex === pacmanSprites.dying.length) {
      clearInterval(deathInterval);
      resetGame();
    }
  }, 100);
}

function checkPelletCollision() {
  const pacmanTile = document.elementFromPoint(pacX * 31 + 15, pacY * 31 + 15);

  if (pacmanTile.classList.contains("pellet")) {
    pacmanTile.classList.remove("pellet");
    pacmanTile.classList.add("empty");
  }

  if (pacmanTile.classList.contains("power-pellet")) {
    pacmanTile.classList.remove("power-pellet");
    pacmanTile.classList.add("empty");
  }
}

// Atualiza a posição do Pac-Man e verifica colisão
function updatePacmanPosition() {
  pacman.style.left = pacX * 31 + "px";
  pacman.style.top = pacY * 31 + "px";
  checkPelletCollision();
}

// Função para reiniciar o jogo
function resetGame() {
  pacX = 1;
  pacY = 1;
  ghosts.forEach((ghost) => {
    ghost.x = 8; // Reposiciona os fantasmas
    ghost.y = 4;
  });
  updatePacmanPosition();
  updateGhostsPosition();
  isDead = false;
  currentSpriteIndex = 0;
}

// Movimento do Pac-Man com teclado
document.addEventListener("keydown", (e) => {
  if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.key)) {
    movePacman(e.key);
  }
});

updatePacmanPosition();
updatePacmanSprite();
setInterval(moveGhosts, 1000); // Movimentação dos fantasmas
setInterval(checkCollision, 100);  // Verifica colisões
