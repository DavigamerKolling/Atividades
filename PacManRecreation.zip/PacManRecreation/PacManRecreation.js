const mazeMap = [
  [4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4],
  [4,1,1,1,1,1,1,1,4,4,4,4,1,1,1,1,1,1,1,4],
  [4,1,4,4,1,4,4,1,4,4,4,4,1,4,4,1,4,4,1,4],
  [4,2,4,4,1,4,4,1,1,1,1,1,1,4,4,1,4,4,2,4],
  [4,1,4,4,1,4,4,1,4,4,4,4,1,4,4,1,4,4,1,4],
  [4,1,1,1,1,1,1,1,0,0,0,0,1,1,1,1,1,1,1,4],
  [4,4,4,1,4,4,1,4,4,0,0,4,4,1,4,4,1,4,4,4],
  [5,1,1,1,4,4,1,4,3,3,3,3,4,1,4,4,1,1,1,5],
  [4,4,4,1,4,4,1,4,4,4,4,4,4,1,4,4,1,4,4,4],
  [4,1,1,1,1,1,1,0,0,0,0,0,0,1,1,1,1,1,1,4],
  [4,1,4,1,4,1,4,4,4,4,4,4,4,4,1,4,1,4,1,4],
  [4,2,1,1,4,1,1,1,1,4,4,1,1,1,1,4,1,1,2,4],
  [4,1,4,4,4,1,4,4,1,4,4,1,4,4,1,4,4,4,1,4],
  [4,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,4],
  [4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4]
];

const container = document.getElementById("game-container");
const pacman = document.getElementById("pacman");
let pacX = 1;
let pacY = 1;
let direction = 'right';
let currentSpriteIndex = 0;
let isDead = false;
pacman.style.left = pacX * 31 + "px";
pacman.style.top = pacY * 31 + "px";
pacman.setAttribute('left', pacX * 31 + "px");
pacman.setAttribute('top', pacY * 31 + "px");

function checkTeleportation(character) {
  const characterPosX = parseInt(character.style.left.replace('px', '') / 31);
  const characterPosY = parseInt(character.style.top.replace('px', '') / 31);

  // Verifica se o personagem está em uma zona de teleporte (bloco '5')
  if (mazeMap[characterPosY][characterPosX] === 5) {
    // Localiza a outra zona de teleporte
    for (let y = 0; y < mazeMap.length; y++) {
      for (let x = 0; x < mazeMap[y].length; x++) {
        if (mazeMap[y][x] === 5 && (x !== characterPosX || y !== characterPosY)) {
          // Teleporta o personagem para o outro bloco de teleporte
          character.style.left = x * 31 + "px";
          character.style.top = y * 31 + "px";

          // Continua com a movimentação do Pacman após o teleporte
          return;
        }
      }
    }
  }
}

let pacmanSprites = {
  up: ['./Sprite/PacMan/Eating/Up/UpEatFrame1.png', './Sprite/PacMan/Eating/Up/UpEatFrame2.png', './Sprite/PacMan/Eating/Up/UpEatFrame3.png'],
  down: ['./Sprite/PacMan/Eating/Down/DownEatFrame1.png', './Sprite/PacMan/Eating/Down/DownEatFrame2.png', './Sprite/PacMan/Eating/Down/DownEatFrame3.png'],
  left: ['./Sprite/PacMan/Eating/Left/LeftEatFrame1.png', './Sprite/PacMan/Eating/Left/LeftEatFrame2.png', './Sprite/PacMan/Eating/Left/LeftEatFrame3.png'],
  right: ['./Sprite/PacMan/Eating/Right/RightEatFrame1.png', './Sprite/PacMan/Eating/Right/RightEatFrame2.png', './Sprite/PacMan/Eating/Right/RightEatFrame3.png'],
  dying: [
    './Sprite/PacMan/Dying/DieFrame1.png', './Sprite/PacMan/Dying/DieFrame2.png', './Sprite/PacMan/Dying/DieFrame3.png',
    './Sprite/PacMan/Dying/DieFrame4.png', './Sprite/PacMan/Dying/DieFrame5.png', './Sprite/PacMan/Dying/DieFrame6.png',
    './Sprite/PacMan/Dying/DieFrame7.png', './Sprite/PacMan/Dying/DieFrame8.png', './Sprite/PacMan/Dying/DieFrame9.png',
    './Sprite/PacMan/Dying/DieFrame10.png', './Sprite/PacMan/Dying/DieFrame11.png'
  ]
};

function createGhost(name, index) {
  const ghost = document.createElement("div");
  ghost.id = name;
  ghost.classList.add("ghost");
  const ghostZones = document.querySelectorAll(".tile.ghost-zone");
  const targetCell = ghostZones[index];
  if (targetCell) {
    targetCell.appendChild(ghost);
  } else {
    console.warn(`ghost-zone[${index}] não encontrada para ${name}`);
  }
  return ghost;
}
function getValidZonesFromDOM(ghostZones) {
  const validZones = [];
  ghostZones.forEach((tile, i) => {
    const x = Math.floor(tile.offsetTop / 31) * 31;
    const y = Math.floor(tile.offsetLeft / 31) * 31;
    validZones.push({ x, y, index: i, element: tile });
  });
  return validZones;
}
let ghostPositions = {
  blinky: [],
  pinky: [],
  inky: [],
  clyde: []
};

let ghostInGhostZone = {
  blinky: true,
  pinky: true,
  inky: true,
  clyde: true
};

function moveGhosts(ghostZones) {
  const validZones = getValidZonesFromDOM(ghostZones);
  const ghostNames = ["blinky", "pinky", "inky", "clyde"];
  if (isDead) return;
  ghostNames.forEach(name => {
    const ghostElement = document.getElementById(name);
    if (!ghostElement || !ghostElement.parentElement) return;
    const parentTile = ghostElement.parentElement;
    const x = Math.floor(parentTile.offsetTop / 31) * 31;
    const y = Math.floor(parentTile.offsetLeft / 31) * 31;
    if (ghostElement.offsetTop === pacman.offsetTop && ghostElement.offsetLeft === pacman.offsetLeft) {
      isDead = true;
      setTimeout(() => {
        resetGame();
      }, 5000);
      return;
    }
    function getNeighbors(x, y) {
      const directions = [
        { dx: -31, dy: 0 },
        { dx: 31, dy: 0 },
        { dx: 0, dy: -31 },
        { dx: 0, dy: 31 }
      ];
      return directions
        .map(({ dx, dy }) => {
          const nx = x + dx;
          const ny = y + dy;
          const zone = validZones.find(zone => zone.x === nx && zone.y === ny);
          if (!zone) return null;
          const isGhostZone = zone.element.classList.contains('ghost-zone');
          if (ghostInGhostZone[name]) {
            return isGhostZone ? null : zone;
          } else {
            return isGhostZone ? null : zone;
          }
        })
        .filter(Boolean);
    }
    const lastPositions = ghostPositions[name];
    const neighbors = getNeighbors(x, y).filter(zone => {
      return !lastPositions.some(pos => pos.x === zone.x && pos.y === zone.y);
    });
    if (neighbors.length > 0) {
      const target = neighbors[Math.floor(Math.random() * neighbors.length)];
      target.element.appendChild(ghostElement);
      lastPositions.push({ x, y });
      if (lastPositions.length > 2) lastPositions.shift();
      ghostInGhostZone[name] = false;
    }
  });
}

const ghostSprites = {
  blinky: {
    normal: {
      up: ['./Sprite/Ghosts/Blinky/Up/BlinkyUp1.png', './Sprite/Ghosts/Blinky/Up/BlinkyUp2.png'],
      down: ['./Sprite/Ghosts/Blinky/Down/BlinkyDown1.png', './Sprite/Ghosts/Blinky/Down/BlinkyDown2.png'],
      left: ['./Sprite/Ghosts/Blinky/Left/BlinkyLeft1.png', './Sprite/Ghosts/Blinky/Left/BlinkyLeft2.png'],
      right: ['./Sprite/Ghosts/Blinky/Right/BlinkyRight1.png', './Sprite/Ghosts/Blinky/Right/BlinkyRight2.png']
    },
    power: {
      up: ['./Sprite/Ghosts/Blinky/Scared/BlinkyScared1.png', './Sprite/Ghosts/Blinky/Scared/BlinkyScared2.png'],
      down: ['./Sprite/Ghosts/Blinky/Scared/BlinkyScared1.png', './Sprite/Ghosts/Blinky/Scared/BlinkyScared2.png'],
      left: ['./Sprite/Ghosts/Blinky/Scared/BlinkyScared1.png', './Sprite/Ghosts/Blinky/Scared/BlinkyScared2.png'],
      right: ['./Sprite/Ghosts/Blinky/Scared/BlinkyScared1.png', './Sprite/Ghosts/Blinky/Scared/BlinkyScared2.png']
    },
    powerAlmostGone: {
      up: ['./Sprite/Ghosts/Blinky/Scared/BlinkyScaredRunningOut1.png', './Sprite/Ghosts/Blinky/Scared/BlinkyScaredRunningOut2.png'],
      down: ['./Sprite/Ghosts/Blinky/Scared/BlinkyScaredRunningOut1.png', './Sprite/Ghosts/Blinky/Scared/BlinkyScaredRunningOut2.png'],
      left: ['./Sprite/Ghosts/Blinky/Scared/BlinkyScaredRunningOut1.png', './Sprite/Ghosts/Blinky/Scared/BlinkyScaredRunningOut2.png'],
      right: ['./Sprite/Ghosts/Blinky/Scared/BlinkyScaredRunningOut1.png', './Sprite/Ghosts/Blinky/Scared/BlinkyScaredRunningOut2.png']
    },
    eaten: {
      up: ['./Sprite/Ghosts/Blinky/Up/BlinkyEatenUp.png'],
      down: ['./Sprite/Ghosts/Blinky/Down/BlinkyEatenDown.png'],
      left: ['./Sprite/Ghosts/Blinky/Left/BlinkyEatenLeft.png'],
      right: ['./Sprite/Ghosts/Blinky/Right/BlinkyEatenRight.png']
    }
  },
  
  pinky: {
    normal: {
      up: ['./Sprite/Ghosts/Pinky/Up/PinkyUp1.png', './Sprite/Ghosts/Pinky/Up/PinkyUp2.png'],
      down: ['./Sprite/Ghosts/Pinky/Down/PinkyDown1.png', './Sprite/Ghosts/Pinky/Down/PinkyDown2.png'],
      left: ['./Sprite/Ghosts/Pinky/Left/PinkyLeft1.png', './Sprite/Ghosts/Pinky/Left/PinkyLeft2.png'],
      right: ['./Sprite/Ghosts/Pinky/Right/PinkyRight1.png', './Sprite/Ghosts/Pinky/Right/PinkyRight2.png']
    },
    power: {
      up: ['./Sprite/Ghosts/Pinky/Scared/PinkyScared1.png', './Sprite/Ghosts/Pinky/Scared/PinkyScared2.png'],
      down: ['./Sprite/Ghosts/Pinky/Scared/PinkyScared1.png', './Sprite/Ghosts/Pinky/Scared/PinkyScared2.png'],
      left: ['./Sprite/Ghosts/Pinky/Scared/PinkyScared1.png', './Sprite/Ghosts/Pinky/Scared/PinkyScared2.png'],
      right: ['./Sprite/Ghosts/Pinky/Scared/PinkyScared1.png', './Sprite/Ghosts/Pinky/Scared/PinkyScared2.png']
    },
    powerAlmostGone: {
      up: ['./Sprite/Ghosts/Pinky/Scared/PinkyScaredRunningOut1.png', './Sprite/Ghosts/Pinky/Scared/PinkyScaredRunningOut2.png'],
      down: ['./Sprite/Ghosts/Pinky/Scared/PinkyScaredRunningOut1.png', './Sprite/Ghosts/Pinky/Scared/PinkyScaredRunningOut2.png'],
      left: ['./Sprite/Ghosts/Pinky/Scared/PinkyScaredRunningOut1.png', './Sprite/Ghosts/Pinky/Scared/PinkyScaredRunningOut2.png'],
      right: ['./Sprite/Ghosts/Pinky/Scared/PinkyScaredRunningOut1.png', './Sprite/Ghosts/Pinky/Scared/PinkyScaredRunningOut2.png']
    },
    eaten: {
      up: ['./Sprite/Ghosts/Pinky/Up/PinkyEatenUp.png'],
      down: ['./Sprite/Ghosts/Pinky/Down/PinkyEatenDown.png'],
      left: ['./Sprite/Ghosts/Pinky/Left/PinkyEatenLeft.png'],
      right: ['./Sprite/Ghosts/Pinky/Right/PinkyEatenRight.png']
    }
  },

  inky: {
    normal: {
      up: ['./Sprite/Ghosts/Inky/Normal/Up/UpFrame1.png', './Sprite/Ghosts/Inky/Normal/Up/UpFrame2.png'],
      down: ['./Sprite/Ghosts/Inky/Normal/Down/DownFrame1.png', './Sprite/Ghosts/Inky/Normal/Down/DownFrame2.png'],
      left: ['./Sprite/Ghosts/Inky/Normal/Left/LeftFrame1.png', './Sprite/Ghosts/Inky/Normal/Left/LeftFrame2.png'],
      right: ['./Sprite/Ghosts/Inky/Normal/Right/RightFrame1.png', './Sprite/Ghosts/Inky/Normal/Right/RightFrame2.png']
    },
    power: {
      up: ['./Sprite/Ghosts/Inky/Power/Up/UpPower1.png', './Sprite/Ghosts/Inky/Power/Up/UpPower2.png'],
      down: ['./Sprite/Ghosts/Inky/Power/Down/DownPower1.png', './Sprite/Ghosts/Inky/Power/Down/DownPower2.png'],
      left: ['./Sprite/Ghosts/Inky/Power/Left/LeftPower1.png', './Sprite/Ghosts/Inky/Power/Left/LeftPower2.png'],
      right: ['./Sprite/Ghosts/Inky/Power/Right/RightPower1.png', './Sprite/Ghosts/Inky/Power/Right/RightPower2.png']
    },
    powerAlmostGone: {
      up: ['./Sprite/Ghosts/Inky/PowerAlmostGone/Up/UpAlmostGone1.png', './Sprite/Ghosts/Inky/PowerAlmostGone/Up/UpAlmostGone2.png'],
      down: ['./Sprite/Ghosts/Inky/PowerAlmostGone/Down/DownAlmostGone1.png', './Sprite/Ghosts/Inky/PowerAlmostGone/Down/DownAlmostGone2.png'],
      left: ['./Sprite/Ghosts/Inky/PowerAlmostGone/Left/LeftAlmostGone1.png', './Sprite/Ghosts/Inky/PowerAlmostGone/Left/LeftAlmostGone2.png'],
      right: ['./Sprite/Ghosts/Inky/PowerAlmostGone/Right/RightAlmostGone1.png', './Sprite/Ghosts/Inky/PowerAlmostGone/Right/RightAlmostGone2.png']
    },
    eaten: {
      up: ['./Sprite/Ghosts/Inky/Eaten/Up/EatenFrame1.png'],
      down: ['./Sprite/Ghosts/Inky/Eaten/Down/EatenFrame1.png'],
      left: ['./Sprite/Ghosts/Inky/Eaten/Left/EatenFrame1.png'],
      right: ['./Sprite/Ghosts/Inky/Eaten/Right/EatenFrame1.png']
    }
  },

  clyde: {
    normal: {
      up: ['./Sprite/Ghosts/Clyde/Normal/Up/UpFrame1.png', './Sprite/Ghosts/Clyde/Normal/Up/UpFrame2.png'],
      down: ['./Sprite/Ghosts/Clyde/Normal/Down/DownFrame1.png', './Sprite/Ghosts/Clyde/Normal/Down/DownFrame2.png'],
      left: ['./Sprite/Ghosts/Clyde/Normal/Left/LeftFrame1.png', './Sprite/Ghosts/Clyde/Normal/Left/LeftFrame2.png'],
      right: ['./Sprite/Ghosts/Clyde/Normal/Right/RightFrame1.png', './Sprite/Ghosts/Clyde/Normal/Right/RightFrame2.png']
    },
    power: {
      up: ['./Sprite/Ghosts/Clyde/Power/Up/UpPower1.png', './Sprite/Ghosts/Clyde/Power/Up/UpPower2.png'],
      down: ['./Sprite/Ghosts/Clyde/Power/Down/DownPower1.png', './Sprite/Ghosts/Clyde/Power/Down/DownPower2.png'],
      left: ['./Sprite/Ghosts/Clyde/Power/Left/LeftPower1.png', './Sprite/Ghosts/Clyde/Power/Left/LeftPower2.png'],
      right: ['./Sprite/Ghosts/Clyde/Power/Right/RightPower1.png', './Sprite/Ghosts/Clyde/Power/Right/RightPower2.png']
    },
    powerAlmostGone: {
      up: ['./Sprite/Ghosts/Clyde/PowerAlmostGone/Up/UpAlmostGone1.png', './Sprite/Ghosts/Clyde/PowerAlmostGone/Up/UpAlmostGone2.png'],
      down: ['./Sprite/Ghosts/Clyde/PowerAlmostGone/Down/DownAlmostGone1.png', './Sprite/Ghosts/Clyde/PowerAlmostGone/Down/DownAlmostGone2.png'],
      left: ['./Sprite/Ghosts/Clyde/PowerAlmostGone/Left/LeftAlmostGone1.png', './Sprite/Ghosts/Clyde/PowerAlmostGone/Left/LeftAlmostGone2.png'],
      right: ['./Sprite/Ghosts/Clyde/PowerAlmostGone/Right/RightAlmostGone1.png', './Sprite/Ghosts/Clyde/PowerAlmostGone/Right/RightAlmostGone2.png']
    },
    eaten: {
      up: ['./Sprite/Ghosts/Clyde/Eaten/Up/EatenFrame1.png'],
      down: ['./Sprite/Ghosts/Clyde/Eaten/Down/EatenFrame1.png'],
      left: ['./Sprite/Ghosts/Clyde/Eaten/Left/EatenFrame1.png'],
      right: ['./Sprite/Ghosts/Clyde/Eaten/Right/EatenFrame1.png']
    }
  }
};

let score = 0;
const scoreDisplay = document.getElementById("score");
function updateScore(points) {
  score += points;
  scoreDisplay.textContent = score;
}

let isPowerMode = false;
let powerModeTimer;
let powerFlashTimer;
let eatenGhosts = new Set();

let ghostZones;

document.addEventListener("DOMContentLoaded", () => {
  createGhost("blinky", 1);
  createGhost("pinky", 1);
  createGhost("inky", 2);
  createGhost("clyde", 2);
  ghostZones = document.querySelectorAll(".tile.empty, .tile.pellet, .tile.power-pellet, .tile.ghost-zone");
  ghostInterval = setInterval(() => moveGhosts(ghostZones), 800);
});

let ghostInterval;

function checkCollisionGhosts() {
  if (isDead) return;
  const ghostElements = document.querySelectorAll('.ghost');
  ghostElements.forEach(ghost => {
    const ghostX = Math.floor(ghost.offsetLeft / 31);
    const ghostY = Math.floor(ghost.offsetTop / 31);

    if (pacX === ghostX && pacY === ghostY) {
      if (isPowerMode && !eatenGhosts.has(ghost.id)) {
        eatenGhosts.add(ghost.id);

        showGhostScore(ghost);
        updateScore(200);

        ghost.style.display = "none";

        // Após 1 segundo, envia o fantasma para a base
        setTimeout(() => {
          moveGhostToBase(ghost);
          ghost.style.display = "block";
          ghost.style.backgroundColor = "purple";
          eatenGhosts.delete(ghost.id);
          // Se ainda estiver no power mode, volta a azul
          if (isPowerMode) {
            ghost.style.backgroundColor = "purple";
          }

        }, 1000);
      } else if (!isPowerMode) {
        isDead = true;
        animateDeath();
        clearInterval(ghostInterval);
        setTimeout(() => {
          resetGame();
          ghostInterval = setInterval(() => moveGhosts(ghostZones), 800);
        }, 2000);
      }
    }
  });
}

mazeMap.forEach((row, y) => {
  row.forEach((cell, x) => {
    const tile = document.createElement("div");
    tile.classList.add("tile");
    switch (cell) {
      case 0:
        tile.classList.add("empty");
        break;
      case 1:
        tile.classList.add("pellet");
        break;
      case 2:
        tile.classList.add("power-pellet");
        break;
      case 3:
        tile.classList.add("ghost-zone");
        break;
      case 4:
        tile.classList.add("wall");
        break;
    }
    tile.style.left = x * 31 + "px";
    tile.style.top = y * 31 + "px";
    tile.setAttribute('top', y * 31 + "px");
    tile.setAttribute('left', x * 31 + "px");
    container.appendChild(tile);
  });
});

function updatePacmanSprite() {
  pacman.style.backgroundImage = `url(${pacmanSprites[direction][currentSpriteIndex]})`;
  currentSpriteIndex = (currentSpriteIndex + 1) % pacmanSprites[direction].length;
}

function animateDeath() {
  let deathInterval = setInterval(() => {
    pacman.style.backgroundImage = `url(${pacmanSprites.dying[currentSpriteIndex]})`;
    currentSpriteIndex++;
    if (currentSpriteIndex === pacmanSprites.dying.length) {
      clearInterval(deathInterval);
      alert("Game Over!");
      resetGame();
    }
  }, 100);
  // AQUI VOCÊ PRECISA INCLUIR A MENSAGEM DE GAME OVER!!
}

function movePacman(dir) {
  if (isDead) return;
  let nextX = pacX;
  let nextY = pacY;

  // Atualiza a direção com base na tecla pressionada
  switch (dir) {
    case "ArrowUp":
      nextY--;
      direction = 'up';
      break;
    case "ArrowDown":
      nextY++;
      direction = 'down';
      break;
    case "ArrowLeft":
      nextX--;
      direction = 'left';
      break;
    case "ArrowRight":
      nextX++;
      direction = 'right';
      break;
  }

  // Verifica se o próximo movimento é válido (não colide com uma parede)
  if (
    nextY >= 0 &&
    nextY < mazeMap.length &&
    nextX >= 0 &&
    nextX < mazeMap[0].length &&
    mazeMap[nextY][nextX] !== 4
  ) {
    pacX = nextX;
    pacY = nextY;

    // Atualiza a posição do Pac-Man no DOM
    pacman.style.left = pacX * 31 + "px";
    pacman.style.top = pacY * 31 + "px";
    pacman.setAttribute('left', pacX * 31 + "px");
    pacman.setAttribute('top', pacY * 31 + "px");

    // Atualiza o sprite do Pac-Man
    updatePacmanSprite();

    // Verifica se o Pac-Man está em uma zona de teleporte
    checkTeleportation(pacman);

    // Verifica se o Pac-Man comeu algum pellet
    checkPelletCollision();
  }
}

// Função para verificar se o Pac-Man está em uma zona de teleporte
function checkTeleportation(character) {
  const characterPosX = parseInt(character.style.left.replace('px', '') / 31);
  const characterPosY = parseInt(character.style.top.replace('px', '') / 31);

  // Verifica se o personagem está em uma zona de teleporte (bloco '5')
  if (mazeMap[characterPosY][characterPosX] === 5) {
    // Localiza a outra zona de teleporte
    for (let y = 0; y < mazeMap.length; y++) {
      for (let x = 0; x < mazeMap[y].length; x++) {
        if (mazeMap[y][x] === 5 && (x !== characterPosX || y !== characterPosY)) {
          // Teleporta o personagem para o outro bloco de teleporte
          character.style.left = x * 31 + "px";
          character.style.top = y * 31 + "px";

          // Faz a movimentação continuar após o teleporte
          pacX = x;
          pacY = y;
          
          return; // Sai da função após o teleporte
        }
      }
    }
  }
}

function contaPellet() {
  const pelletsRestantes = document.querySelectorAll(".pellet, .power-pellet").length;
  if (pelletsRestantes === 0) {
    setTimeout(() => {
      alert("You Win!");
      resetGame();
    }, 500);
  }
}

function checkPelletCollision() {
  const tiles = document.querySelectorAll(".tile");
  let pacCurrentPos = document.getElementById("pacman");
  let leftPacman = pacCurrentPos.getAttribute("left");
  let topPacman = pacCurrentPos.getAttribute("top");  
  tiles.forEach(tile =>{
    let leftTile = tile.getAttribute("left");
    let topTile = tile.getAttribute("top");
    if(leftTile===leftPacman && topTile===topPacman){
      if (tile.classList.contains("pellet")) {
        tile.classList.remove("pellet");
        tile.classList.add("empty");
        updateScore(10); // +10 pontos
        contaPellet();
      }
      if (tile.classList.contains("power-pellet")) {
        tile.classList.remove("power-pellet");
        tile.classList.add("empty");
        updateScore(50); // +50 pontos
        activatePowerMode(); // Aqui entra a lógica da power pellet se quiser mais tarde
        contaPellet();
      }      
      if (tile.classList.contains("pellet")) {
        tile.classList.remove("pellet");
        tile.classList.add("empty");
        contaPellet();
      }
      if (tile.classList.contains("power-pellet")) {
        tile.classList.remove("power-pellet");
        tile.classList.add("empty");
        // AQUI VOCÊ TEM QUE ACIONAR O EFEITO DA POWER PELLET 
        contaPellet();
      }
    }
  });
}

function activatePowerMode() {
  clearTimeout(powerModeTimer);
  clearInterval(powerFlashTimer);

  isPowerMode = true;
  eatenGhosts.clear();

  const ghosts = document.querySelectorAll('.ghost');
  ghosts.forEach(ghost => {
    ghost.style.backgroundColor = 'purple';
  });

  // Alternância nos últimos 3 segundos
  powerFlashTimer = setTimeout(() => {
    let flash = true;
    powerFlashTimer = setInterval(() => {
      ghosts.forEach(ghost => {
        if (!eatenGhosts.has(ghost.id)) {
          ghost.style.backgroundColor = flash ? 'white' : 'purple';
        }
      });
      flash = !flash;
    }, 300);
  }, 7000);

  
  powerModeTimer = setTimeout(() => {
    clearInterval(powerFlashTimer);
    isPowerMode = false;
    ghosts.forEach(ghost => {
      if (ghost.getAttribute("id")==="clyde"){
        ghost.style.backgroundColor = "orange" ;
      } else if(ghost.getAttribute("id")==="inky"){
        ghost.style.backgroundColor = "cyan" ;
      } else if(ghost.getAttribute("id")==="pinky"){
        ghost.style.backgroundColor = "pink" ;
      } else if(ghost.getAttribute("id")==="blinky"){
        ghost.style.backgroundColor = "red" ;
      }
    });
  }, 10000);
}

function showGhostScore(ghost) {
  const scoreElement = document.createElement("div");
  scoreElement.textContent = "200";
  scoreElement.style.position = "absolute";
  scoreElement.style.left = ghost.offsetLeft + "px";
  scoreElement.style.top = ghost.offsetTop + "px";
  scoreElement.style.color = "white";
  scoreElement.style.fontSize = "18px";
  scoreElement.style.fontFamily = "Arial";
  scoreElement.style.zIndex = 20;
  document.body.appendChild(scoreElement);

  updateScore(200);
  setTimeout(() => {
    scoreElement.remove();
  }, 1000);
}

function moveGhostToBase(ghost) {
  const ghostZones = document.querySelectorAll(".tile.ghost-zone");
  const baseZone = ghostZones[1]; 
  const baseX = baseZone.offsetLeft;
  const baseY = baseZone.offsetTop;
  const ghostName=ghost.getAttribute("id");

  let ghostX = ghost.offsetLeft;
  let ghostY = ghost.offsetTop;
  let moveInterval = setInterval(() => {
    const deltaX = baseX - ghostX;
    const deltaY = baseY - ghostY;

    if (Math.abs(deltaX) <= 31 && Math.abs(deltaY) <= 31) {
      clearInterval(moveInterval);
      ghost.style.left = baseX + 'px';
      ghost.style.top = baseY + 'px';
      ghostX = baseX;
      ghostY = baseY;
      ghost.style.backgroundColor = 'purple'; 
    } else {
      if (Math.abs(deltaX) > Math.abs(deltaY)) {
        ghostX += deltaX > 0 ? 31 : -31;
      } else {
        ghostY += deltaY > 0 ? 31 : -31;
      }
      ghost.style.left = ghostX + 'px';
      ghost.style.top = ghostY + 'px';
    }
  }, 100);
  ghost.remove();
  createGhost(`${ghostName}`, 1);
}

function resetGame() {
  pacX = 1;
  pacY = 1;
  const ghosts = document.querySelectorAll('.ghost');
  ghosts.forEach(ghost => ghost.remove());

  createGhost("blinky", 1);
  createGhost("pinky", 1);
  createGhost("inky", 2);
  createGhost("clyde", 2);

  ghostInGhostZone = {
    blinky: true,
    pinky: true,
    inky: true,
    clyde: true
  };

  pacman.style.left = pacX * 31 + "px";
  pacman.style.top = pacY * 31 + "px";
  isDead = false;
  currentSpriteIndex = 0;

  score = 0;
  scoreDisplay.textContent = score;
}

document.addEventListener("keydown", (e) => {
  if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.key)) {
    movePacman(e.key);
  }
});

updatePacmanSprite();
setInterval(checkCollisionGhosts, 100);



