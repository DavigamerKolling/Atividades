// script.js

// Definindo os elementos
let pacman = document.getElementById("pacman");
let ghost = document.getElementById("ghost");
let gameContainer = document.getElementById("game-container");

let pacmanPosition = { top: 180, left: 180 }; // Posição inicial do Pac-Man
let ghostPosition = { top: 10, left: 10 }; // Posição inicial do fantasma
let speed = 5; // Velocidade do Pac-Man

// Função para movimentar o Pac-Man
function movePacman(e) {
  switch (e.key) {
    case "ArrowUp":
      if (pacmanPosition.top > 0) pacmanPosition.top -= speed;
      break;
    case "ArrowDown":
      if (pacmanPosition.top < 370) pacmanPosition.top += speed;
      break;
    case "ArrowLeft":
      if (pacmanPosition.left > 0) pacmanPosition.left -= speed;
      break;
    case "ArrowRight":
      if (pacmanPosition.left < 370) pacmanPosition.left += speed;
      break;
  }

  // Atualiza a posição do Pac-Man na tela
  pacman.style.top = pacmanPosition.top + "px";
  pacman.style.left = pacmanPosition.left + "px";
}

// Função para movimentar o fantasma (movimento simples)
function moveGhost() {
  // Movimento aleatório simples do fantasma (movimento horizontal ou vertical)
  let direction = Math.random() > 0.5 ? "horizontal" : "vertical";
  if (direction === "horizontal") {
    ghostPosition.left += (Math.random() > 0.5 ? 1 : -1) * speed;
    if (ghostPosition.left < 0) ghostPosition.left = 0;
    if (ghostPosition.left > 370) ghostPosition.left = 370;
  } else {
    ghostPosition.top += (Math.random() > 0.5 ? 1 : -1) * speed;
    if (ghostPosition.top < 0) ghostPosition.top = 0;
    if (ghostPosition.top > 370) ghostPosition.top = 370;
  }

  // Atualiza a posição do fantasma
  ghost.style.top = ghostPosition.top + "px";
  ghost.style.left = ghostPosition.left + "px";
}

// Função para verificar se Pac-Man colidiu com o fantasma
function checkCollision() {
  if (
    pacmanPosition.top < ghostPosition.top + 30 &&
    pacmanPosition.top + 30 > ghostPosition.top &&
    pacmanPosition.left < ghostPosition.left + 30 &&
    pacmanPosition.left + 30 > ghostPosition.left
  ) {
    alert("Game Over! O Pac-Man foi pego pelo fantasma!");
    resetGame();
  }
}

// Sprites para as direções e animação de morte
let pacmanSprites = {
    up: ['./Sprite/PacMan/Eating/Up/UpEatFrame1.png', './Sprite/PacMan/Eating/Up/UpEatFrame2.png', './Sprite/PacMan/Eating/Up/UpEatFrame3.png'],
    down: ['./Sprite/PacMan/Eating/Down/DownEatFrame1.png', './Sprite/PacMan/Eating/Down/DownEatFrame2.png', './Sprite/PacMan/Eating/Down/DownEatFrame3.png'],
    left: ['./Sprite/PacMan/Eating/Left/LeftEatFrame1.png', './Sprite/PacMan/Eating/Left/LeftEatFrame2.png', './Sprite/PacMan/Eating/Left/LeftEatFrame3.png'],
    right: ['./Sprite/PacMan/Eating/Right/RightEatFrame1.png', './Sprite/PacMan/Eating/Right/RightEatFrame2.png', './Sprite/PacMan/Eating/Right/RightEatFrame3.png'],
    dying: [
      './Sprite/PacMan/Dying/DieFrame1.png', './Sprite/PacMan/Dying/DieFrame2.png', './Sprite/PacMan/Dying/DieFrame3.png', './Sprite/PacMan/Dying/DieFrame4.png',
      './Sprite/PacMan/Dying/DieFrame5.png', './Sprite/PacMan/Dying/DieFrame6.png', './Sprite/PacMan/Dying/DieFrame7.png', './Sprite/PacMan/Dying/DieFrame8.png',
      './Sprite/PacMan/Dying/DieFrame9.png', './Sprite/PacMan/Dying/DieFrame10.png', './Sprite/PacMan/Dying/DieFrame11.png'
    ]
  };
  
  let currentSpriteIndex = 0; // Controle do sprite atual
  let pacmanDirection = 'right'; // Direção inicial do Pac-Man
  let isDead = false; // Controle de estado de morte
  
  // Função para atualizar a imagem do Pac-Man com base na direção
  function updatePacmanSprite() {
    if (isDead) return;
  
    pacman.style.backgroundImage = `url(${pacmanSprites[pacmanDirection][currentSpriteIndex]})`;
  }
  
  // Função para animar a morte do Pac-Man
  function animateDeath() {
    let deathInterval = setInterval(() => {
      pacman.style.backgroundImage = `url(${pacmanSprites.dying[currentSpriteIndex]})`;
      currentSpriteIndex++;
      if (currentSpriteIndex === pacmanSprites.dying.length) {
        clearInterval(deathInterval);
        resetGame();
      }
    }, 100);
  }
  
  // Função para movimentar o Pac-Man
  function movePacman(e) {
    if (isDead) return; // Não permite mover o Pac-Man após morrer
  
    switch (e.key) {
      case "ArrowUp":
        if (pacmanPosition.top > 0) pacmanPosition.top -= speed;
        pacmanDirection = 'up';
        break;
      case "ArrowDown":
        if (pacmanPosition.top < 370) pacmanPosition.top += speed;
        pacmanDirection = 'down';
        break;
      case "ArrowLeft":
        if (pacmanPosition.left > 0) pacmanPosition.left -= speed;
        pacmanDirection = 'left';
        break;
      case "ArrowRight":
        if (pacmanPosition.left < 370) pacmanPosition.left += speed;
        pacmanDirection = 'right';
        break;
    }
  
    // Atualiza a posição do Pac-Man na tela
    pacman.style.top = pacmanPosition.top + "px";
    pacman.style.left = pacmanPosition.left + "px";
  
    // Atualiza a imagem do Pac-Man
    updatePacmanSprite();
  
    // Troca de sprite (animação de movimento)
    currentSpriteIndex = (currentSpriteIndex + 1) % pacmanSprites[pacmanDirection].length;
  }
  
  // Função para verificar se o Pac-Man colidiu com o fantasma
  function checkCollision() {
    if (
      pacmanPosition.top < ghostPosition.top + 30 &&
      pacmanPosition.top + 30 > ghostPosition.top &&
      pacmanPosition.left < ghostPosition.left + 30 &&
      pacmanPosition.left + 30 > ghostPosition.left
    ) {
      isDead = true;
      animateDeath();
    }
  }

// Função para reiniciar o jogo
function resetGame() {
  pacmanPosition = { top: 180, left: 180 }; // Posição inicial do Pac-Man
  ghostPosition = { top: 10, left: 10 }; // Posição inicial do fantasma
  pacman.style.top = pacmanPosition.top + "px";
  pacman.style.left = pacmanPosition.left + "px";
  ghost.style.top = ghostPosition.top + "px";
  ghost.style.left = ghostPosition.left + "px";
}

// Adicionando um ouvinte de evento para movimentação do Pac-Man
window.addEventListener("keydown", movePacman);

// Movendo o fantasma a cada 1 segundo
setInterval(() => {
  moveGhost();
  checkCollision();
}, 1000);
