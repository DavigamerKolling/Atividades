const mazeMap = [
  [4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4],
  [4,0,0,0,4,4,4,4,4,4,4,4,4,4,4,4,4,0,0,4],
  [4,0,4,0,4,0,0,0,0,0,0,0,0,0,0,0,4,0,1,4],
  [4,0,4,0,4,0,4,4,4,4,4,4,4,4,4,0,4,0,1,4],
  [4,0,4,0,4,0,4,0,0,0,0,0,0,0,4,0,4,0,0,4],
  [4,0,4,0,4,0,4,0,4,4,4,4,4,0,4,0,4,0,2,4],
  [4,0,4,0,4,0,4,0,4,0,0,0,4,0,4,0,4,0,0,4],
  [4,0,4,0,4,0,4,0,4,4,4,4,4,0,4,0,4,0,1,4],
  [4,0,1,1,4,4,4,4,4,4,4,4,4,4,4,1,1,0,2,4],
  [4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4]
];

const container = document.getElementById("game-container");

function drawMaze() {
  mazeMap.forEach(row => {
    row.forEach(cell => {
      const tile = document.createElement("div");
      tile.classList.add("tile");

      switch (cell) {
        case 0:
          tile.classList.add("empty");
          break;
        case 1:
          tile.classList.add("pellet");
          break;
        case 2:
          tile.classList.add("power-pellet");
          break;
        case 3:
          tile.classList.add("ghost-zone");
          break;
        case 4:
          tile.classList.add("wall");
          break;
      }

      container.appendChild(tile);
    });
  });
}

drawMaze();
