const connection = require('./models/db');
const util = require('util');
const express = require('express');
const app = express();
const path = require('path');
const query = util.promisify(connection.query).bind(connection);
app.use(express.json());
app.use(express.static(path.join(__dirname, 'src')));
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'index.html'));
});

app.get('/produtos', async (req, res) => {
    try {
        const results = await query('SELECT * FROM produtos');
        res.json(results);
    }   catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/produtos', async (req, res) => {
    const { nome, preco } = req.body;
    try {
        const results = await query('INSERT INTO produtos (nome, preco) VALUES (?, ?)', [nome, preco]);
        res.status(201).json({ id: results.insertId });
    }   catch (err) {
        console.error('Erro no MySQL:', err);
        res.status(500).json({ error: err.message });
    }
});

app.put('/produtos/:id', async (req, res) => {
    const { id } = req.params;
    const { nome, preco } = req.body;
    try {
        const results = await query('UPDATE produtos SET nome = ?, preco = ? WHERE id = ?', [nome, preco, id]);
        res.json({ message: 'Dados atualizados com sucesso' });
    }   catch (err) {
        console.error('Erro no MySQL:', err);
        res.status(500).json({ error: err.message});
    }
});

app.delete('/produtos/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const results = await query('DELETE FROM produtos WHERE id = ?', [id]);
        res.json({ message: 'Registro deletado com sucesso' });
    }   catch (err) {
        console.error('Erro no MySQL:', err);
        res.status(500).json({ error: err.message });
    }
});

app.listen(8080, () => {
    console.log('Servidor rodando em http://localhost:8080');
});