document.addEventListener('DOMContentLoaded', () => {
    const listaProdutosDiv = document.getElementById('lista-produtos');
    const formAdicionar = document.getElementById('form-adicionar');
    const formEditar = document.getElementById('form-editar');
    const btnCancelarEdicao = document.getElementById('btn-cancelar-edicao');
    async function carregarProdutos() {
        try {
            const response = await fetch('http://localhost:8080/produtos');
            const produtos = await response.json();
            renderizarProdutos(produtos);
        } catch (error) {
            console.error('Erro ao carregar os produtos:', error);
            listaProdutosDiv.textContent = 'Não foi possível carregar os produtos. Verifique se o servidor está rodando.';
        }
    }

    function renderizarProdutos(produtos) {
        listaProdutosDiv.innerHTML = '';

        produtos.forEach(produto => {
            const itemDiv = document.createElement('div');
            itemDiv.className = 'produto-item';
            itemDiv.innerHTML = `
                <span>ID: ${produto.id} | ${produto.nome} - R$ ${produto.preco}</span>
                <div>
                    <button onclick="prepararEdicao(${produto.id}, '${produto.nome}', ${produto.preco})">Editar</button>
                    <button onclick="deletarProduto(${produto.id})">Excluir</button>
                </div>
            `;
            listaProdutosDiv.appendChild(itemDiv);
        });
    }

    async function adicionarProduto(nome, preco) {
        try {
            await fetch('http://localhost:8080/produtos', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({nome, preco})
            });
            carregarProdutos();
        } catch (error) {
            console.error('Erro ao adicionar o produto:', error);
        }
    }

    async function atualizarProduto(id, nome, preco) {
        try {
            await fetch(`http://localhost:8080/produtos/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({nome, preco})
            });
            carregarProdutos();
        } catch (error) {
            console.error('Erro ao editar o produto:', error);
        }
    }

    window.prepararEdicao = (id, nome, preco) => {
        document.getElementById('edit-id').value = id;
        document.getElementById('edit-nome').value = nome;
        document.getElementById('edit-preco').value = preco;
        formAdicionar.style.display = 'none';
        formEditar.style.display = 'block';
    };

    async function deletarProduto(id) {
        if (confirm('Tem certeza que deseja excluir este produto?')) {
            try {
                await fetch(`http://localhost:8080/produtos/${id}`, {
                    method: 'DELETE'
                });
                carregarProdutos();
            } catch (error) {
                console.error('Erro ao deletar o produto:', error);
            }
        }
    }
    window.deletarProduto = deletarProduto;


    formAdicionar.addEventListener('submit', (e) => {
        e.preventDefault();
        const nome = document.getElementById('nome').value;
        const preco = parseFloat(document.getElementById('preco').value);
        adicionarProduto(nome, parseFloat(preco));
        formAdicionar.reset();
    });

    formEditar.addEventListener('submit', (e) => {
        e.preventDefault();
        const id = parseInt(document.getElementById('edit-id').value);
        const nome = document.getElementById('edit-nome').value;
        const preco = parseFloat(document.getElementById('edit-preco').value);
        atualizarProduto(id, nome, parseFloat(preco));
        formEditar.style.display = 'none';
        formAdicionar.style.display = 'block';
    });

    btnCancelarEdicao.addEventListener('click', () => {
        formEditar.style.display = 'none';
        formAdicionar.style.display = 'block';
    });

    carregarProdutos();
});
